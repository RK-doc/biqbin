/*
 * UpperBoundComputation.cpp
 *
 *  Created on: 10.08.2017
 *      Author: mesiebenhofe
 */

#include "UpperBoundComputation.h"

UpperBoundComputation::UpperBoundComputation() {


}

UpperBoundComputation::~UpperBoundComputation() {

}
