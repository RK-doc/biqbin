/*
 * Structures.cpp
 *
 *  Created on: 30.08.2017
 *      Author: mesiebenhofe
 */

#include "Structures.h"

Structures::Structures() {


}

Structures::~Structures() {

}
